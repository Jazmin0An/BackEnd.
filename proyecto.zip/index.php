<?php 
$request = $_GET['url'] ?? 'home';
$routes = explode('/', $request);

$controller = $routes[0] ?? 'home';
$method = $routes[1] ?? 'index';
$param = $routes[2] ?? null;

// Incluir el controlador correspondiente
$controllerFile = "src/controllers/" . ucfirst($controller) . "Controller.php";

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    $controllerClass = ucfirst($controller) . "Controller";
    $instance = new $controllerClass();
    
    if (method_exists($instance, $method)) {
        $instance->$method($param);
    } else {
        echo "Método no encontrado.";
    }
} else {
    echo "Página no encontrada.";
}
?>