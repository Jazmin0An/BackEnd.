<?php 
class Database {
    private static $db;

    public static function conectar() {
        if (!self::$db) {
            self::$db = new PDO("mysql:host=localhost;dbname=perfumeria", "root", "");
            self::$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        return self::$db;
    }
}
?>