<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Perfume</title>
    <link rel="stylesheet" href="/public/styles.css">
</head>
<body>
    <h1>Agregar Nuevo Perfume</h1>
    <form action="/perfumes/crear" method="POST" enctype="multipart/form-data">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>
        
        <label>Marca:</label>
        <input type="text" name="marca" required>
        
        <label>Descripción:</label>
        <textarea name="descripcion"></textarea>
        
        <label>Notas Olfativas:</label>
        <input type="text" name="notas_olfativas">
        
        <label>Tamaño:</label>
        <input type="text" name="tamaño">
        
        <label>Tipo:</label>
        <select name="tipo">
            <option value="Eau de Toilette">Eau de Toilette</option>
            <option value="Eau de Parfum">Eau de Parfum</option>
            <option value="Parfum">Parfum</option>
            <option value="Cologne">Cologne</option>
        </select>
        
        <label>Precio:</label>
        <input type="number" name="precio" step="0.01" required>
        
        <label>Stock:</label>
        <input type="number" name="stock" required>
        
        <label>Imagen:</label>
        <input type="text" name="imagen">
        
        <button type="submit">Guardar</button>
    </form>
    <a href="/perfumes/listar">Volver a la lista</a>
</body>
</html>
