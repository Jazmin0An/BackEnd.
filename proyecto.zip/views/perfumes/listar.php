<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Perfumes</title>
    <link rel="stylesheet" href="/public/styles.css">
</head>
<body>
    <h1>Lista de Perfumes</h1>
    <a href="/perfumes/crear">Agregar Perfume</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Marca</th>
                <th>Descripción</th>
                <th>Notas Olfativas</th>
                <th>Tamaño</th>
                <th>Tipo</th>
                <th>Precio</th>
                <th>Stock</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($perfumes as $perfume): ?>
            <tr>
                <td><?= htmlspecialchars($perfume['id']) ?></td>
                <td><?= htmlspecialchars($perfume['nombre']) ?></td>
                <td><?= htmlspecialchars($perfume['marca']) ?></td>
                <td><?= htmlspecialchars($perfume['descripcion']) ?></td>
                <td><?= htmlspecialchars($perfume['notas_olfativas']) ?></td>
                <td><?= htmlspecialchars($perfume['tamaño']) ?></td>
                <td><?= htmlspecialchars($perfume['tipo']) ?></td>
                <td>$<?= htmlspecialchars($perfume['precio']) ?></td>
                <td><?= htmlspecialchars($perfume['stock']) ?></td>
                <td>
                    <?php if (!empty($perfume['imagen_url'])): ?>
                        <img src="<?= htmlspecialchars($perfume['imagen_url']) ?>" width="50" alt="Imagen de <?= htmlspecialchars($perfume['nombre']) ?>">
                    <?php else: ?>
                        Sin imagen
                    <?php endif; ?>
                </td>
                <td>
                    <a href="/perfumes/editar?id=<?= $perfume['id'] ?>">Editar</a>
                    <a href="/perfumes/eliminar?id=<?= $perfume['id'] ?>">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
