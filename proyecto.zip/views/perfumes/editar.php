<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfume</title>
    <link rel="stylesheet" href="/public/styles.css">
</head>
<body>
<h1>Editar Perfume</h1>
<form action="/perfumes/editar" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $perfume['id'] ?>">
    <label>Nombre:</label>
    <input type="text" name="nombre" value="<?= $perfume['nombre'] ?>" required>
    
    <label>Marca:</label>
    <input type="text" name="marca" value="<?= $perfume['marca'] ?>" required>
    
    <label>Descripción:</label>
    <textarea name="descripcion"><?= $perfume['descripcion'] ?></textarea>
    
    <label>Notas Olfativas:</label>
    <input type="text" name="notas_olfativas" value="<?= $perfume['notas_olfativas'] ?>">
    
    <label>Tamaño:</label>
    <input type="text" name="tamaño" value="<?= $perfume['tamaño'] ?>">
    
    <label>Tipo:</label>
    <select name="tipo">
        <option value="Eau de Toilette" <?= $perfume['tipo'] == 'Eau de Toilette' ? 'selected' : '' ?>>Eau de Toilette</option>
        <option value="Eau de Parfum" <?= $perfume['tipo'] == 'Eau de Parfum' ? 'selected' : '' ?>>Eau de Parfum</option>
        <option value="Parfum" <?= $perfume['tipo'] == 'Parfum' ? 'selected' : '' ?>>Parfum</option>
        <option value="Cologne" <?= $perfume['tipo'] == 'Cologne' ? 'selected' : '' ?>>Cologne</option>
    </select>
    
    <label>Precio:</label>
    <input type="number" name="precio" step="0.01" value="<?= $perfume['precio'] ?>" required>
    
    <label>Stock:</label>
    <input type="number" name="stock" value="<?= $perfume['stock'] ?>" required>
    
    <label>Imagen:</label>
    <input type="text" name="imagen" value="<?= $perfume['imagen_url'] ?>">
    <br>
    <button type="submit">Actualizar</button>
</form>
    <a href="/perfumes/listar">Volver a la lista</a>
</body>
</html>
