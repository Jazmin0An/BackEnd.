<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Perfume</title>
    <link rel="stylesheet" href="/public/styles.css">
</head>
<body>
<h2>Eliminar Perfume</h2>
<p>¿Seguro que deseas eliminar el perfume "<?= $perfume['nombre'] ?>" de la marca "<?= $perfume['marca'] ?>"?</p>
<form action="/perfumes/eliminar" method="POST">
    <input type="hidden" name="id" value="<?= $perfume['id'] ?>">
    <button type="submit">Sí, eliminar</button>
    <a href="listar.php">Cancelar</a>
</form>
    <a href="/perfumes/listar">Volver a la lista</a>
</body>
</html>
