<?php 
require_once "config/db.php";

class Perfume {
    private $db;
    
    // Método para crear un perfume
    public static function create($datos) {
        $db = Database::conectar();
        $sql = "INSERT INTO perfumes (nombre, marca, descripcion, notas_olfativas, tamaño, tipo, precio, stock, imagen_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            $datos['nombre'],
            $datos['marca'],
            $datos['descripcion'],
            $datos['notas_olfativas'],
            $datos['tamaño'],
            $datos['tipo'],
            $datos['precio'],
            $datos['stock'],
            $datos['imagen']
        ]);
    }

    // Método para obtener un perfume por ID
    public static function getById($id) {
        $db = Database::conectar();
        $sql = "SELECT * FROM perfumes WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar un perfume
    public static function update($datos) {
        $db = Database::conectar();
        $sql = "UPDATE perfumes SET nombre = ?, marca = ?, descripcion = ?, notas_olfativas = ?, tamaño = ?, tipo = ?, precio = ?, stock = ?, imagen_url = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            $datos['nombre'],
            $datos['marca'],
            $datos['descripcion'],
            $datos['notas_olfativas'],
            $datos['tamaño'],
            $datos['tipo'],
            $datos['precio'],
            $datos['stock'],
            $datos['imagen'],
            $datos['id']
        ]);
    }

    // Método para eliminar un perfume
    public static function delete($id) {
        $db = Database::conectar();
        $sql = "DELETE FROM perfumes WHERE id = ?";
        $stmt = $db->prepare($sql);
        return $stmt->execute([$id]);
    }

    public static function getAll() {
        $db = Database::conectar();
        $sql = "SELECT * FROM perfumes";
        return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

}
?>