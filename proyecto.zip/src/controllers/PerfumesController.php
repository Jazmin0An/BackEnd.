<?php 
require_once "src/models/Perfume.php";

class PerfumesController {

    public function crear() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            Perfume::create($_POST);
            header("Location: /perfumes/listar");
        } else {
            require_once "views/perfumes/crear.php";
        }
    }

    public function listar() {
        $perfumes = Perfume::getAll();
        require_once "views/perfumes/listar.php";
    }    

    public function editar() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            Perfume::update($_POST);
            header("Location: /perfumes/listar");
            exit;
        } else {
            $id = $_GET['id'] ?? null;
            if (!$id) {
                die("ID no proporcionado.");
            }
            $perfume = Perfume::getById($id);
            require_once "views/perfumes/editar.php";
        }
    }

    public function eliminar() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id = $_POST['id'] ?? null;
            if ($id) {
                Perfume::delete($id);
                header("Location: /perfumes/listar");
                exit;
            }
        } else {
            $id = $_GET['id'] ?? null;
            if (!$id) {
                die("ID no proporcionado.");
            }
            $perfume = Perfume::getById($id);
            require_once "views/perfumes/eliminar.php";
        }
    }
}
?>